// Conjectura de Collatz
let value = 939123123;
for(;;) {
    /* Suponemos que el value ingresado ya es de tipo Number. Sino podriamos escribir value = Number(value) para pasarlo 
        a number en caso de recibir "939123123".
    */
    if (value % 2 == 0) {
        // Si es par dividimos por dos
        value = value / 2;
        console.log(value);
    } else {
        // Si es impar, aplicamos 3n + 1
        value = (value * 3) + 1;
        console.log(value);
    }
}
